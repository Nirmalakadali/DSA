#ifndef _MUSICPLAYER_H_
#define _MUSICPLAYER_H_
#include "song.h"
typedef struct que
{
    Song *end;

} que;
typedef struct  MusicPlayer
{
    Song *currentsong;
    Song *playingsong;
    que *Queue;

} musicPlayer;

musicPlayer *createMusicPlayer();
int addSongToQueue(musicPlayer *mm, Song *ss);
int removeSongFromQueue(musicPlayer* mp, int x);
int playSong(musicPlayer* mp);
Song* getCurrentSong(musicPlayer* mp);
#endif