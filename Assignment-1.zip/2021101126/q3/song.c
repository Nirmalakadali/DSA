#include "song.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
Song *makeSong(char *songs, char *name, float time)
{
    Song *new = (Song *)malloc(sizeof(Song));
    new->Artist=(char*)malloc(sizeof(20*sizeof(char)));
    new->Name=(char*)malloc(sizeof(20* sizeof(char)));
    strcpy(new->Artist, name);
    strcpy(new->Name, songs);
    new->duration = time;
    new->next=NULL;
    return new;
}