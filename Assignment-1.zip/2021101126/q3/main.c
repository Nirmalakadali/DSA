#include "song.h"
#include "musicplayer.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
int main()
{
    char c[100];
    musicPlayer *mp = createMusicPlayer();
    Song **songs = (Song **)malloc(1000 * sizeof(Song *));
    int numsongs = 0;
    while (1)
    {
        scanf("%s", c);
        if (!(strcmp(c, "ADD")))
        {
            // CREATE NEW SONG
            char *name = (char *)malloc(100 * sizeof(char));
            char *artist = (char *)malloc(100 * sizeof(char));
            float dur;
            scanf(" %s %s %f", name, artist, &dur);
            songs[numsongs++] = makeSong(name, artist, dur);
            printf("Song %s with artist %s and duration %f created\n", name, artist, dur);
        }
        else if (!(strcmp(c, "INSERT")))
        {
            // INSERT SONG TO QUEUE OF MUSIC PLAYER
            char name[100];
            scanf(" %s", name);
            // FIND THE SONG IN THE LIST
            // NOTE: 2 SONGS WILL NOT HAVE THE SAME NAME IN OUR CODES!
            int idx = -1;
            for (int a = 0; a < numsongs; a++)
                if (strcmp(name, songs[a]->Name) == 0)
                    idx = a;
            // NO SUCH SONG
            if (idx == -1)
            {
                printf("No song found with name %s\n", name);
                continue;
            }
            // FOUND SONG, ADD TO MUSIC PLAYER
            if (addSongToQueue(mp, songs[idx]) == 1)
                // UNSUCCESSFUL OPERATION
                printf("Song %s couldn't be added to the music player\n", name);
            else
                // SUCCESSFUL OPERATION
                printf("Song %s added successfully\n", name);
        }
        else if (!(strcmp(c, "REMOVE")))
        {
            // REMOVE SONG FROM MUSIC PLAYER
            int idx;
            scanf("%d", &idx);
            // REMOVE SONG FROM THE INDEX ASKED
            if (removeSongFromQueue(mp, idx) == 1)
                printf("Song at index %d couldn't be removed\n", idx);
            else
                printf("Song at index %d removed successfully\n", idx);
        }
        else if (!(strcmp(c, "PLAY")))
        {
            // PLAY THE SONG
            int n = playSong(mp);
            if (n == 0)
                printf("Playing song\n");
            else
                printf("Couldn't play song\n");
        }
        else if (!(strcmp(c, "GET")))
        {
            // GET THE CURRENT SONG PLAYING
            Song *s = getCurrentSong(mp);
            if (s == NULL)
                printf("No song playing\n");
            else
                printf("Song %s is playing right now\n", s->Name);
        }
        else if (!(strcmp(c, "EXIT")))
            break;
        else
            printf("Invalid command\n");
    }
    return 0;
}
