#ifndef _SONG_H_
#define _SONG_H_

typedef struct Song
{
    char *Name;
    char *Artist;
    int duration;
    struct Song *next;
} Song;

Song *makeSong(char *,char*, float);
#endif