#include "song.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdlib.h>
#include "musicplayer.h"
//create the musicPlayerjust like creating the node
musicPlayer*createMusicPlayer()
{
    musicPlayer*mp = (musicPlayer*)malloc(sizeof(musicPlayer));
    mp->currentsong = NULL;
    mp->playingsong =NULL;
    mp->Queue = NULL;
    return mp;
}

//function to add the song to the list 
int addSongToQueue(musicPlayer*mm, Song *ss)
{
    //checks if musicPlayeris null or not
    //if it is null allocates the memory and stores in the musicplayer(music)
    if (mm->currentsong == NULL)
    {
        que *temp = (que *)malloc(sizeof(que));
        mm->Queue = temp;
        temp->end = ss;
        mm->currentsong = ss;
        return 0;
    }
    //else adds at the end of the music and updates the link of previous node and inserted node(song)
    else
    {
        mm->Queue->end->next = ss;
        mm->Queue->end = ss;
    }
}


//function to remove the song from the list
int removeSongFromQueue(musicPlayer*p, int i)
{
    int j = 0;
    Song *temp = p->currentsong;
    Song *Psong = NULL;
    Song *Csong; 
    if (i == 0)
    {
        p->currentsong = temp->next;
        free(temp);
        return 0;
    }
    else
    {
        for(int j = 0; j < i; j++)
        {
            Psong = temp;
            temp = temp->next;
        }
        Psong->next = temp->next;
        free(temp);
        return 0;
    }
    return 1;
}

//function to play song 
int playSong(musicPlayer*mp)
{
    //checks if musicPlayeris empty or not 
    // if it is empty then functions fails 
    if (mp->Queue == NULL)
    {
        return 1;
    }
    //else displays the current song pllaying and after playing deletes the song from the musicplayer
    mp->playingsong=mp->currentsong;
    Song *temp = mp->currentsong;
    mp->currentsong = mp->currentsong->next;
    return 0;
}

// function to know the current song
Song *getCurrentSong(musicPlayer*mp)
{
    //just returns the first node in the list
    return mp->playingsong;

}
