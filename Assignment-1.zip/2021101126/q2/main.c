#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "complex.h"

int main()
{
    char s[5];
    int f;
    while (1)
    {
        scanf("%s %d", s, &f);
        complex a, b;
        if (!(strcmp(s, "ADD")))
        {

            a.n = f;
            b.n = f;
            a.data = (float *)malloc(f * sizeof(float));
            b.data = (float *)malloc(f * sizeof(float));
            int i = 0;
            for (int i = 0; i < f; i++)
            {
                float temp;
                scanf("%f", &temp);
                a.data[i] = temp;
            }
            for (int i = 0; i < f; i++)
            {
                float temp;
                scanf("%f", &temp);
                b.data[i] = temp;
            }
            print(add(a, b));
        }

        else if (!(strcmp(s, "SUB")))
        {

            a.n = f;
            b.n=f;
            a.data = (float *)malloc(f * sizeof(float));
            b.data = (float *)malloc(f * sizeof(float));
            int i = 0;
            for (int i = 0; i < f; i++)
            {
                float temp;
                scanf("%f", &temp);
                a.data[i] = temp;
            }
            for (int i = 0; i < f; i++)
            {
                float temp;
                scanf("%f", &temp);
                b.data[i] = temp;
            }
            print(sub(a, b));
        }
        else if (!(strcmp(s, "DOT")))
        {

            a.n = f;
            b.n=f;
            a.data = (float *)malloc( f* sizeof(float));
            b.data = (float *)malloc(f * sizeof(float));
            int i = 0;
            for (int i = 0; i < f; i++)
            {
                float temp;
                scanf("%f", &temp);
                a.data[i] = temp;
            }
            for (int i = 0; i < f; i++)
            {
                float temp;
                scanf("%f", &temp);
                b.data[i] = temp;
            }
            printf("%.2f\n", dot(a, b));
        }
        else if (!(strcmp(s, "COS")))
        {

            a.n = f;
            b.n=f;
            a.data = (float *)malloc(f * sizeof(float));
            b.data = (float *)malloc(f * sizeof(float));
            int i = 0;
            for (int i = 0; i < f; i++)
            {
                float temp;
                scanf("%f", &temp);
                a.data[i] = temp;
            }
            for (int i = 0; i < f; i++)
            {
                float temp;
                scanf("%f", &temp);
                b.data[i] = temp;
            }
            printf("%f\n", COS(a, b));
        }
        else if (!(strcmp(s, "MOD")))
        {

            a.n = f;
            b.n=f;
            a.data = (float *)malloc(f * sizeof(float));
            b.data = (float *)malloc(f * sizeof(float));
            int i = 0;
            for (int i = 0; i < f; i++)
            {
                float temp;
                scanf("%f", &temp);
                a.data[i] = temp;
            }
            printf("%.2f\n", mod(a));
        }
        else if (!(strcmp(s, "EXIT")))
        {
            break;
        }
        else
        {
            printf("please eneter valid command\n");
        }
    }
}
