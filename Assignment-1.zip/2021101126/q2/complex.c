#include "complex.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
complex add(complex a, complex b)
{
    complex c;
    c.n = a.n;
    c.data = (float *)malloc(c.n * (sizeof(float)));
    for (int i = 0; i < c.n; i++)
    {
        c.data[i] = a.data[i] + b.data[i];
    }

    return c;
}

complex sub(complex a, complex b)
{
    complex c;
    c.n = a.n;
    c.data = (float *)malloc(c.n * (sizeof(float)));
    for (int i = 0; i < c.n; i++)
    {
        c.data[i] = a.data[i] - b.data[i];
    }

    return c;
}

float mod(complex a)
{
    float value = 0;
    float square = 0;
    for (int i = 0; i < a.n; i++)
    {
        value = a.data[i];
        square = square + value * value;
    }
    return sqrt(square);
}

float dot(complex a, complex b)
{
    float multi = 0;
    float value = 1;
    for (int i = 0; i < b.n; i++)
    {
        value = a.data[i] * b.data[i];
        multi = multi + value;
    }
    return multi;
}

float COS(complex a, complex b)
{
    float d = 0;
    float m = 1;
    float x;
    d = dot(a, b);
    m = (mod(a) * mod(b));
    x = d / m;
    return x;
}

void print(complex a)
{
    for (int i = 0; i < a.n; i++)
    {
        printf("%g ", a.data[i]);
    }
    printf("\n");
}
