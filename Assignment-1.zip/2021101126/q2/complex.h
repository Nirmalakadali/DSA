#ifndef _CO_H_
#define _CO_H_

typedef struct complex{
    int n;
    float *data;
}complex;

complex add(complex ,complex );

complex sub(complex ,complex );

float mod(complex );

float dot(complex ,complex );

float COS(complex ,complex );

void print(complex);
#endif 