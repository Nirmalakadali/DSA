#include "my_dll.h"
#include "node.h"
//to insert a node at the end of the list
void insert(my_dll *head, int x)
{
    //allocate memory to the inserting node
    node *temp = (node *)malloc(sizeof(node));
    temp->data = x;
    temp->next = NULL;
    temp->prev = NULL;
    //check if list is empty i.e., no node present in it
    if (head->root == NULL)
    {
        head->root = temp;
    }
    //inserting at the end
    else
    {
        node *p;
        p = head->root;
        while (p->next != NULL)
        {
            p = p->next;
        }
        p->next = temp;
        temp->prev = p;
    }
}
//inserting node at the given position

void insert_at(my_dll *head, int x, int i)
{
    //allocate memory to the inserting node
    int s = get_size(head);
    if (i > s-1)
    {
        printf("Invalid index to insert\n");
    }
    //create pointer to the node to traverse the whole list
    else
    {
        node *temp = (node *)malloc(sizeof(node));
        temp->data = x;
        temp->next = NULL;
        temp->prev = NULL;
        node *p;
        p = head->root;
        int count = 0;
        //if we  neeed to insert the node at the head
        if (i == 0)
        {
            temp->next = p;
            temp->prev = NULL;
            head->root = temp;
        }
        //if we need to insert the node at the midlle of the list
        else if (i > 0)
        {
            while (p->next != NULL)
            {
                if (count == i - 1)
                    break;
                p = p->next;
                count++;
            }

            p->next->prev = temp;
            temp->next = p->next;
            p->next = temp;
            temp->prev = p;
        }
    }
}

//To find the given element present in the list or not
int find(my_dll *head, int x)
{
    node *p;
    p = head->root;
    int flag = 0, count = 0;
    //transversing the whole list to find the elemengt present or not
    while (p != NULL)
    {
        //if element is found then it breaks the while condition
        if (p->data == x)
        {
            flag = 1;
            break;
        }
        //else continues checking untill the p==NULL
        else
        {
            flag = 0;
        }
        p = p->next;
        count = count + 1;
    }
    //Retuens index of the element if it is find otherwise it returns -1
    if (flag == 1)
    {
        return count;
    }
    else
    {
        return -1;
    }
}
//to calculate the size of the list
int get_size(my_dll *head)
{
    node *temp;
    temp = head->root;
    int count = 0;
    while (temp != NULL)
    {
        temp = temp->next;
        count++;
    }
    return count;
}

//deleting the even nodes in the list
void prune(my_dll *head)
{
    if (head->root != NULL)
    {
        //allocating memory to the one node pointer for furtheruse
        node *temp = (node *)malloc(sizeof(node));
        //first node which have even index
        node *evenNode = head->root;
        //link of the first node points to next node which is odd pointer
        node *oddNode = head->root->next;

        while (evenNode != NULL && oddNode != NULL)
        {
            //updating the even node index to delete the odd node by free ing
            evenNode->next = oddNode->next;
            free(oddNode);
            //storing the updated even node after deleting from the list in the temp
            temp = evenNode;

            evenNode = evenNode->next;

            //transverses untill the end of the list
            if (evenNode != NULL)
            {
                //updating even node pointer
                evenNode->prev = temp;
                //updating the oddnode
                oddNode = evenNode->next;
            }
        }
    }
}

//prints the list in reverse
void print_reverse(my_dll *head)
{
    node *temp = head->root;
    //Reaching the end of the list using temp
    while (temp->next != NULL)
    {
        temp = temp->next;
    }
    node *temp1 = temp;
    //coming back to the head and prints the elements in the linked list in reverse order
    while (temp1 != NULL)
    {
        printf("%d  ", temp1->data);
        temp1 = temp1->prev;
    }
    printf("\n");
}

//deleting the node at the given position
void delete (my_dll *head, int pos)
{
    //getting size of the linked list
    int s = get_size(head);
    //if we want to delete the node at the head
    if (pos >= s)
    {

        printf("Invalid index\n");
    }
   
    else
    {
        struct Node *p;
        p = head->root;
        if (pos == 0)
        {
            head->root = p->next;
            p->next->prev = NULL;
            free(p);
        }
        //if we want to delete the node at the end of the list
        else if (pos == s - 1)
        {
            while (p->next != NULL)
            {
                p = p->next;
            }
            p->prev->next = NULL;
            free(p);
        }
        //if we want to delete any nodes expect the starting and ending node in the list
        else
        {
            int i = 0;
            while (i < pos)
            {
                //breaks after reaching the index of deleting node
                p = p->next;
                i++;
            }
            //transfering the links of deleting node to the next node of the deleting node
            p->prev->next = p->next;
            p->next->prev = p->prev;

            free(p);
        }
    }
}
//prints the list
void print(my_dll *head)
{
    node *temp;
    //traverses the whole list using temp
    temp = head->root;
    while (temp != NULL)
    {
        printf("%d  ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}
