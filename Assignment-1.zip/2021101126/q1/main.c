#include "my_dll.h"
#include "node.h"
#include <stddef.h>
int main()
{
    char s[100];
    struct my_dll *list;
    list = create();
    while (1)
    {
        scanf("%s", s);
        if (!(strcmp(s, "insert")))
        {
            int x;
            scanf("%d", &x);
            insert(list,x);
            //insert function to add at the end of list
        }
        else if (!(strcmp(s, "insert_at")))
        {
            int i, x;
            scanf("%d %d", &x, &i);
            insert_at(list, x, i);
            //insert at the disired position
        }
        else if (!(strcmp(s, "delete")))
        {
            int i;
            scanf("%d", &i);
            delete (list, i);
            //to delete the given element
        }
        else if (!(strcmp(s, "find")))
        {
            int x;
            scanf("%d", &x);
            printf("-> %d",find(list, x));
            //find the given position of given number
        }
        else if (!(strcmp(s, "prune")))
        {
            prune(list);
            //delete all odd indexes of the given list
        }
        else if (!(strcmp(s, "print")))
        {
            //print the list
            print(list);
        }
        else if (!(strcmp(s, "print_reverse")))
        {
            print_reverse(list);
            //prints the list in reverse order
        }
        else if (!(strcmp(s, "get_size")))
        {
            printf("%d", get_size(list));
            //prints the size of the list
        }
        else if (!(strcmp(s, "EXIT")))
            break;
        else
        {
            printf("please enter valid command\n");
        }
    }
    return 0;
}