#ifndef _MY_DLL_H_
#define _MY_DLL_H_
#include "node.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stddef.h>
typedef struct my_dll
{
    node *root;
} my_dll;

my_dll *create();

void insert(my_dll *, int x);
void insert_at(my_dll *head, int x, int i);
void delete (my_dll *head, int i);
int find(my_dll *head, int x);
void prune(my_dll *head);
void print(my_dll *head);
void print_reverse(my_dll *head);
int get_size(my_dll *head);

#endif