#ifndef _NODE_H_
#define _NODE_H_
#include "my_dll.h"
#include <stddef.h>
typedef struct Node
{
    int data;
    struct Node *prev;
    struct Node *next;
} node;


#endif