#include "my_dll.h"
#include "node.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stddef.h>
my_dll *create()
{
    my_dll *head = (my_dll *)malloc(sizeof(my_dll));
    head->root = NULL;
    return head;
}