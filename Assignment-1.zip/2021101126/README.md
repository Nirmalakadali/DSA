> # Instructions to compile programs

## Kadali Lakshmi Nirmala | 2021101126

---
* **GCC compiler**
* **Linus OS (Preferably Ubuntu)**
---
<br/>

> # Index of programs
  - [***Q1-Doubly Linked List***](#q1-doubly-linked-list)
  - [***Q2-Complex Number ADT***](#q2-complex-number-adt)
  - [***Q3-Music Player ADT***](#mq3-usic-player-adt)
---
---
<br/>


> ### Note : The following commands are with respect to the compiler I used which is gcc and i run it on ubuntu

<br/>

>   ## NOTE: **To exit the any program give `exit` command in every program**

<br/>

# **Q1-Doubly Linked List**

* Name of the my_dll header filebsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : my_dll.h
* Name of the node header file   &nbsp;&nbsp; bsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  : node.h
* Name of the my_dll &nbsp; **C** &nbsp;  file  &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : my_dll.h
* Name of the node &nbsp;  **C** &nbsp; file &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : node.c
* Name of the main file nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;: main.c
<br/>
<br/>

# **Q2-Complex Number ADT**


* Name of the complex header file &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;: complex.h
* Name of the complex **C** file &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;  &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;: complex.c
* Name of the main file&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;  &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; &nbsp;  : main.c
<br/>
<br/>

# **Q-3Music Player ADT**

* Name of the song header file  &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; : my_dll.h
* Name of the musicplayer header file   &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;  : node.h
* Name of song  &nbsp; **C** &nbsp;  file  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; : my_dll.h
* Name of the musicplayer &nbsp;  **C** &nbsp; file &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; : node.c
* Name of the main file &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;  : main.c




> ## Compilation ( compilation using makefile)
<br/>

```bash
$ make all
```
<br/>

> Output of the above command in terminal
<br/>

```
gcc ./q1/node.c ./q1/my_dll.c ./q1/main.c -o q1.out
gcc ./q2/complex.c ./q2/main.c -lm -o q2.out
gcc ./q3/song.c ./q3/musicplayer.c ./q3/main.c -o q3.out
```
<br/>

> To execute the first program

```
$ ./q1.out
```
<br/>

> To perform the second program

```
$ ./q2.out
```
<br/>

> To perform the third program

```
$ ./q3.out
```

> Note: All outputs are prints on the terminal according to our given input, inputs also given in the terminal



