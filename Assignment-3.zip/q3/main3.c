#include "hash.h"
#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#define a 1
#define b 10
#define CountBuckets 10

int main(int argc,char* argv[])
{
    struct HashTable* T= init_hash_table(a,b,CountBuckets);
    FILE *fp;
    char string[100];
    int data;

    fp=fopen(argv[1],"r");
    while(fscanf(fp,"%s",string)!=EOF)
    {
        if(!strcmp("INSERT",string))
        {
            
            fscanf(fp,"%d",&data);
            T= insert(T,data);
        }
        else if(!strcmp("SEARCH",string))
        {
    
            fscanf(fp,"%d",&data);
            int s= search(T,data);
            if(s)
            {
                printf("YES\n");
            }
            else
            {
                printf("NO\n");
            }
        }
        else if(!strcmp("DELETE",string))
        {
            fscanf(fp,"%d",&data);
            T = Delete(T,data);
        }
    }
    fclose(fp);
    print_table(T);
    
    
    return 0;
}