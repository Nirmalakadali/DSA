#include <stdlib.h>
#include <stdio.h>
#include "hash.h"
struct Item *Find(struct HashTable *,int );
int gethash(struct HashTable *, int );
struct HashTable *init_hash_table(int a, int b, int Buckets)
{
    struct HashTable *HT = (struct HashTable *)malloc(sizeof(struct HashTable));
    HT->a = a;
    HT->b = b;
    HT->countBucket = Buckets;
    HT->buckets = (struct Bucket *)malloc(sizeof(struct Bucket) * Buckets);
    if (HT->buckets == NULL)
    {
        return 0;
    }
    for (int i = 0; i < Buckets; i++)
    {
        HT->buckets[i].items = (struct Item *)malloc(sizeof(struct Item));
        HT->buckets[i].items->next = NULL;
        HT->buckets[i].items->frequency=0;
    }
    return HT;
}

struct Item *Find(struct HashTable *T,int key)
{
    struct Item *pos=NULL;
    int k;
    k=gethash(T,key);
    
    pos=T->buckets[k].items->next;
    while ((pos != NULL) && (pos->key != key))
    {
        pos = pos->next;
       
    }
    return pos;

}

struct HashTable *insert(struct HashTable *T, int key)
{
    struct Item *position;
    int k = gethash(T, key);
    position = Find(T, key);
    if (position == NULL)
    {
        position =(struct Item*) malloc(sizeof(struct Item));
        if (position == NULL)
        {
            return 0;
        }
        position->next = T->buckets[k].items->next;
        position->key = key;
        position->frequency = 1;
        T->buckets[k].items->next = position;
    }
    else
    {
        position->frequency++;
    }
    return T;
}


int gethash(struct HashTable *t, int key)
{
    int a = t->a;
    int b = t->b;
    int count = t->countBucket;
    int fn = (a * key + b) % count;
    return fn;
}


bool search(struct HashTable *T, int key)
{
    struct Item *position=NULL;
    int k;
    k = gethash(T, key);
    position = T->buckets[k].items->next;
    while ((position != NULL) && (position->key != key))
    {
        position = position->next;
    }
    return true;
}


struct HashTable *Delete(struct HashTable *T, int key)
{
    int k;
    struct Item *Search, prev;
    k = gethash(T, key);
    Search = T->buckets[k].items->next;
    while (Search != NULL)
    {
        if (Search->next != NULL && Search->next->key == key)
        {
            if (Search->next->frequency > 1)
                Search->next->frequency--;
            else
            {
                struct Item*temp=Search->next;
                Search->next = Search->next->next;
                free(temp);
            }
        }
        Search=Search->next;
    }
    return T;
}


void print_table(struct HashTable *T)
{
    int i = 0;
    while (i < T->countBucket)
    {
        struct Item *t = T->buckets[i].items->next;
        while (t != NULL)
        {
            printf("%d  %d", t->key, t->frequency);
            t = t->next;
        }
        i++;
        printf("\n");
    }
}
