#include <stdio.h>
#include <stdlib.h>
#include <string.h>
long long int Pow(long long int, long long int);
long long int pos(long long int,long long  int, char);
long long int main()
{
    long long int nor;
    scanf("%lld", &nor);
    long long int test;
    scanf("%lld", &test);
    while (test--)
    {
        long long int rn;
        scanf("%lld", &rn);
        char arr[100001];
        scanf("%s", arr);
        long long int l = strlen(arr);
        long long int var, i = 0;
        long long int n = nor + 1;
        while (n % 2 == 0)
        {
            i++;
            n = n / 2;
        }
        long long int height = i;
        long long int st = pos(height, rn, arr[0]);
        for (long long int k = 1; k < l; k++)
        {
            st = pos(height, st, arr[k]);
        }
        printf("%lld\n", st);
    }
    return 0;
}

long long int Pow(long long int X, long long int Y)
{
    if (Y == 0)
        return 1;
    else
        return Pow(X, Y - 1) * X;
}
long long int pos(long long int height, long long int n, char str)
{
    long long int temp, temp1;
    long long int i = 0;
    temp = n;
    while (temp % 2 == 0)
    {
        i++;
        temp = temp / 2;
    }
    long long int level = i + 1;
    long long int num1, num2;

    if (str == 'U')
    {
        if (level == height)
        {
            return n;
        }
        else
        {
            num1 = n + Pow(2, level - 1);
            num2 = n - Pow(2, level - 1);
            if (num2 == 0)
            {
                return num1;
            }
            else
            {
                temp1 = num1;
                long long int i = 0;
                while (temp1 % 2 == 0)
                {
                    i++;
                    temp1 = temp1 / 2;
                }
                if (i + 1 == level + 1)
                {
                    return num1;
                }
                else
                {
                    return num2;
                }
            }
        }
    }
    if (str == 'R')
    {
        if (level == 1)
        {
            return n;
        }
        else
        {
            n = n + Pow(2, level - 2);
            return n;
        }
    }
    if (str == 'L')
    {
        if (level == 1)
        {
            return n;
        }
        else
        {
            n = n - Pow(2, level - 2);
            return n;
        }
    }
}