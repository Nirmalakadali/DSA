#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#define MAX 1000001
typedef int ElementType;
ElementType stridx = 0;
typedef char Elementchar;
struct Node
{
    Elementchar data;
    struct Node *left;
    struct Node *right;
    ElementType idx;
};

struct Tree
{
    struct Node **treenode;
};

struct Tree *Createtree(ElementType n)
{
    struct Tree *t;
    t = (struct Tree *)malloc(sizeof(struct Tree));
    t->treenode = (struct Node **)malloc(sizeof(struct Node) * n);
    for (ElementType i = 0; i < n; i++)
    {
        t->treenode[i] = (struct Node *)malloc(sizeof(struct Node));
        t->treenode[i]->left = NULL;
        t->treenode[i]->right = NULL;
        t->treenode[i]->data = '1';
    }
    return t;
}
void read(ElementType index, ElementType n, struct Tree *T, char *initialstring);
void left_insert(struct Tree *t, ElementType L, ElementType R, Elementchar *initialstring);
void right_insert(struct Tree *t, ElementType L, ElementType R, Elementchar *initialstring);
void Constructtree(struct Tree *t, ElementType L, ElementType R, ElementType I, Elementchar *initialstring);
void PreOrder(struct Node *N, Elementchar *comparestring);
void query1(struct Tree *T, Elementchar *comparestring);
void query2(Elementchar *secondstring, Elementchar *comparestring, struct Tree *T);
int main()
{
    ElementType n;
    scanf("%d", &n);
    struct Tree *T;
    Elementchar initialstring[n + 1];
    Elementchar secondstring[MAX];
    Elementchar comparestring[MAX];
    scanf("%s", initialstring);
    ElementType index;
    T = Createtree(n);
    read(index, n, T, initialstring);
    if (n == 1)
    {
        T->treenode[0]->data = initialstring[0];
    }
    PreOrder(T->treenode[index], comparestring);
    comparestring[stridx] = '\0';
    stridx = 0;
    scanf("%s", secondstring);
    ElementType t;
    scanf("%d", &t);
    ElementType test=0;
    while (test<t)
    {
        ElementType Q;
        scanf("%d", &Q);
        if (Q == 1)
        {
            ElementType index;
            query1(T, comparestring);
        }
        if (Q == 2)
        {
            query2(secondstring, comparestring, T);
        }
        test++;
    }
    return 0;
}
void left_insert(struct Tree *t, ElementType L, ElementType R, Elementchar *initialstring)
{
    t->treenode[R - 1]->data = initialstring[R - 1];
    t->treenode[L - 1]->left = t->treenode[R - 1];
}
void right_insert(struct Tree *t, ElementType L, ElementType R, Elementchar *initialstring)
{
    t->treenode[R - 1]->data = initialstring[R - 1];
    t->treenode[L - 1]->right = t->treenode[R - 1];
}
void Constructtree(struct Tree *t, ElementType L, ElementType R, ElementType I, Elementchar *initialstring)
{
    if (t->treenode[L - 1]->data == '1')
    {
        t->treenode[L - 1]->data = initialstring[L - 1];
    }
    if (I == 2)
    {
        right_insert(t, L, R, initialstring);
    }
    if (I == 1)
    {
        left_insert(t, L, R, initialstring);
    }
    
}

void PreOrder(struct Node *N, Elementchar *comparestring)
{
    if (N == NULL)
        return;
    comparestring[stridx] = N->data;
    N->idx = stridx;
    stridx++;
    PreOrder(N->left, comparestring);
    PreOrder(N->right, comparestring);
}
void query1(struct Tree *T, Elementchar *comparestring)
{
    ElementType a;
    Elementchar ch;
    scanf("%d %c", &a, &ch);
    T->treenode[a - 1]->data = ch;
    comparestring[T->treenode[a - 1]->idx] = ch;
}
void query2(Elementchar *secondstring, Elementchar *comparestring, struct Tree *T)
{
    ElementType a;
    ElementType b;
    ElementType c;
    scanf("%d %d %d", &a, &b, &c);
    Elementchar modifiedstring[b - a + 2], finalstring[MAX];
    ElementType n = b - a + 1;
    for (ElementType i = a - 1, j = 0; i < b, j < n; i++, j++)
    {
        modifiedstring[j] = secondstring[i];
    }
    modifiedstring[n] = '\0';

    if (strncmp(modifiedstring, &comparestring[T->treenode[c - 1]->idx], n) == 0)
    {
        printf("YES\n");
    }
    else
    {
        printf("NO\n");
    }
}
void read(ElementType index, ElementType n, struct Tree *T, char *initialstring)
{
    for (ElementType i = 0; i < n - 1; i++)
    {
        ElementType L;
        ElementType R;
        ElementType I;
        scanf("%d %d %d", &L, &R, &I);
        if (i == 0)
        {
            index = L - 1;
        }
        Constructtree(T, L, R, I, initialstring);
    }
}
