#ifndef _QUEUE_H_
#define _QUEUE_H_
#include "tree.h"
#include <stdio.h>
typedef struct Queue* Que;
struct Queue
{
    long long int qsize;
    long long int front;
    long long int rear;
    long long int numElements;
    node *items;
};

Que create_Q(long long int size);
void Enque(Que Q, node x);
long long int Isempty(Que Q);
void Deque(Que Q);
#endif