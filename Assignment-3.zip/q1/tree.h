#ifndef _TREE_H_
#define _TREE_H_

typedef struct node* node;
struct node
{
    long long int data;
    struct node* left;
    struct node* right;
};
typedef node QElement;


struct ret_arr{
    long long int summ;
    long long int order;
    long long int minn;
    long long int maxx;
};


node Create_Treenode(long long int x);
void Inorder(node root);
long long int Find_noise(node curr_node);
struct ret_arr *find_ans(node curr_node);
long long int min(long long int a, long long int b);
struct ret_arr *find_ans_1(node curr_node);
void print();
#endif