#include "tree.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "queue.h"

node Create_Treenode(long long int x)
{
    if (x == 0)
    {
        return NULL;
    }
    
    node New_node= (node)malloc(sizeof(struct node));
    New_node->data = x;
    New_node->left = NULL;
    New_node->right = NULL;
    return New_node;
}

void Inorder(node root)
{
    if (root == NULL)
    {
        return;
    }
    Inorder(root->left);
    printf("%lld ",root->data);
    Inorder(root->right);
    
}

long long int ans=1e15;
long long int Find_noise(node curr_node)
{
    if (curr_node == NULL)
    {
        return 0;
    }
    long long int total = curr_node->data;
    total += Find_noise(curr_node->left);
    total += Find_noise(curr_node->right);
    if (total < ans)
    {
        ans = total;
    }
    
    return total;

}

long long int min(long long int a, long long int b)
{
    if(a <= b)
        return a;
    else
        return b;
}

struct ret_arr *find_ans(node curr_node)
{
    struct ret_arr *ret = (struct ret_arr *)malloc(sizeof(struct ret_arr));
    if(curr_node == NULL)
    {
        ret->summ = 0; ret->order = 3; ret->minn = -1e15; ret->maxx = 1e15;
        return ret;
    }
    long long int total = curr_node->data;
    struct ret_arr *left_node_info = (struct ret_arr *)malloc(sizeof(struct ret_arr));
    struct ret_arr *right_node_info = (struct ret_arr *)malloc(sizeof(struct ret_arr));
    left_node_info = find_ans(curr_node->left);
    right_node_info = find_ans(curr_node->right);
    total += left_node_info->summ;
    total += right_node_info->summ;

    long long int l_summ, l_order, l_minn, l_maxx;
    long long int r_summ, r_order, r_minn, r_maxx;
    l_summ = left_node_info->summ; l_order = left_node_info->order; l_minn = left_node_info->minn; l_maxx = left_node_info->maxx;
    r_summ = right_node_info->summ; r_order = right_node_info->order; r_minn = right_node_info->minn; r_maxx = right_node_info->maxx;

    if((l_order == 3) && (r_order == 3)) // NULL && NULL
    {
        ret->summ = curr_node->data; ret->order = 2; ret->minn = curr_node->data; ret->maxx = curr_node->data;
    }
    else if((l_order == 3) && (r_order == 2)) // NULL && BOTH
    {
        if(curr_node->data == r_minn)
        {
            ret->summ = total; ret->order = 2; ret->minn = curr_node->data; ret->maxx = curr_node->data;
        }
        else if(curr_node->data < r_minn)
        {
            ret->summ = total; ret->order = 0; ret->minn = curr_node->data; ret->maxx = r_maxx;
        }
        else if(curr_node->data > r_minn)
        {
            ret->summ = total; ret->order = 1; ret->minn = r_minn; ret->maxx = curr_node->data;
        }
    }
    else if((l_order == 2) && (r_order == 3)) // BOTH && NULL
    {
        if(curr_node->data == l_minn)
        {
            ret->summ = total; ret->order = 2; ret->minn = curr_node->data; ret->maxx = curr_node->data;
        }
        else if(curr_node->data < l_minn)
        {
            ret->summ = total; ret->order = 1; ret->minn = curr_node->data; ret->maxx = l_maxx;
        }
        else if(curr_node->data > l_minn)
        {
            ret->summ = total; ret->order = 0; ret->minn = l_minn; ret->maxx = curr_node->data;
        }
    }
    else if((l_order == 3) && (r_order == 0)) // NULL && Asc
    {
        if(curr_node->data <= r_minn)
        {
            ret->summ = total; ret->order = 0; ret->minn = curr_node->data; ret->maxx = r_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 3) && (r_order == 1)) // NULL && Des
    {
        if(curr_node->data >= r_maxx)
        {
            ret->summ = total; ret->order = 1; ret->minn = r_minn; ret->maxx = curr_node->data;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 0) && (r_order == 3)) // Asc && NULL
    {
        if(curr_node->data >= l_maxx)
        {
            ret->summ = total; ret->order = 0; ret->minn = l_minn; ret->maxx = curr_node->data;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 1) && (r_order == 3)) // Des && NULL
    {
        if(curr_node->data <= l_minn)
        {
            ret->summ = total; ret->order = 1; ret->minn = curr_node->data; ret->maxx = l_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 0) && (r_order == 0)) // Asc && Asc
    {
        if((curr_node->data >= l_maxx) && (curr_node->data <= r_minn))
        {
            ret->summ = total; ret->order = 0; ret->minn = l_minn; ret->maxx = r_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 0) && (r_order == 1)) // Asc && Des
    {
        ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
    }
    else if((l_order == 0) && (r_order == 2)) // Asc && BOTH
    {
        if((curr_node->data >= l_maxx) && (curr_node->data <= r_minn))
        {
            ret->summ = total; ret->order = 0; ret->minn = l_minn; ret->maxx = r_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 1) && (r_order == 0)) // Des && Asc
    {
        ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
    }
    else if((l_order == 1) && (r_order == 1)) // Des && Des
    {
        if((curr_node->data <= l_minn) && (curr_node->data >= r_maxx))
        {
            ret->summ = total; ret->order = 1; ret->minn = r_minn; ret->maxx = l_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 1) && (r_order == 2)) // Des && BOTH
    {
        if((curr_node->data <= l_minn) && (curr_node->data >= r_maxx))
        {
            ret->summ = total; ret->order = 1; ret->minn = r_minn; ret->maxx = l_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 2) && (r_order == 0)) // BOTH && Asc
    {
        if((curr_node->data >= l_maxx) && (curr_node->data <= r_minn))
        {
            ret->summ = total; ret->order = 0; ret->minn = l_minn; ret->maxx = r_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 2) && (r_order == 1)) // BOTH && Des
    {
        if((curr_node->data <= l_minn) && (curr_node->data >= r_maxx))
        {
            ret->summ = total; ret->order = 1; ret->minn = r_minn; ret->maxx = l_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 2) && (r_order == 2)) // BOTH && BOTH
    {
        if((curr_node->data == l_minn) && (curr_node->data == r_minn))
        {
            ret->summ = total; ret->order = 2; ret->minn = curr_node->data; ret->maxx = curr_node->data;
        }
        else if((curr_node->data >= l_maxx) && (curr_node->data <= r_minn))
        {
            ret->summ = total; ret->order = 0; ret->minn = l_minn; ret->maxx = r_maxx;
        }
    }
    // hi
    if(ret->order != -1)
        ans = min(ans,total);
    return ret;
}

struct ret_arr *find_ans_1(node curr_node)
{
    struct ret_arr *ret = (struct ret_arr *)malloc(sizeof(struct ret_arr));
    if(curr_node == NULL)
    {
        ret->summ = 0; ret->order = 3; ret->minn = -1e15; ret->maxx = 1e15;
        return ret;
    }
    long long int total = curr_node->data;
    struct ret_arr *left_node_info = (struct ret_arr *)malloc(sizeof(struct ret_arr));
    struct ret_arr *right_node_info = (struct ret_arr *)malloc(sizeof(struct ret_arr));
    left_node_info = find_ans_1(curr_node->left);
    right_node_info = find_ans_1(curr_node->right);
    total += left_node_info->summ;
    total += right_node_info->summ;

    long long int l_summ, l_order, l_minn, l_maxx;
    long long int r_summ, r_order, r_minn, r_maxx;
    l_summ = left_node_info->summ; l_order = left_node_info->order; l_minn = left_node_info->minn; l_maxx = left_node_info->maxx;
    r_summ = right_node_info->summ; r_order = right_node_info->order; r_minn = right_node_info->minn; r_maxx = right_node_info->maxx;

    if((l_order == 3) && (r_order == 3)) // NULL && NULL
    {
        ret->summ = curr_node->data; ret->order = 2; ret->minn = curr_node->data; ret->maxx = curr_node->data;
    }
    else if((l_order == 3) && (r_order == 2)) // NULL && BOTH
    {
        if(curr_node->data == r_minn)
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
        else if(curr_node->data < r_minn)
        {
            ret->summ = total; ret->order = 0; ret->minn = curr_node->data; ret->maxx = r_maxx;
        }
        else if(curr_node->data > r_minn)
        {
            ret->summ = total; ret->order = 1; ret->minn = r_minn; ret->maxx = curr_node->data;
        }
    }
    else if((l_order == 2) && (r_order == 3)) // BOTH && NULL
    {
        if(curr_node->data == l_minn)
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
        else if(curr_node->data < l_minn)
        {
            ret->summ = total; ret->order = 1; ret->minn = curr_node->data; ret->maxx = l_maxx;
        }
        else if(curr_node->data > l_minn)
        {
            ret->summ = total; ret->order = 0; ret->minn = l_minn; ret->maxx = curr_node->data;
        }
    }
    else if((l_order == 3) && (r_order == 0)) // NULL && Asc
    {
        if(curr_node->data < r_minn)
        {
            ret->summ = total; ret->order = 0; ret->minn = curr_node->data; ret->maxx = r_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 3) && (r_order == 1)) // NULL && Des
    {
        if(curr_node->data > r_maxx)
        {
            ret->summ = total; ret->order = 1; ret->minn = r_minn; ret->maxx = curr_node->data;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 0) && (r_order == 3)) // Asc && NULL
    {
        if(curr_node->data > l_maxx)
        {
            ret->summ = total; ret->order = 0; ret->minn = l_minn; ret->maxx = curr_node->data;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 1) && (r_order == 3)) // Des && NULL
    {
        if(curr_node->data < l_minn)
        {
            ret->summ = total; ret->order = 1; ret->minn = curr_node->data; ret->maxx = l_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 0) && (r_order == 0)) // Asc && Asc
    {
        if((curr_node->data > l_maxx) && (curr_node->data < r_minn))
        {
            ret->summ = total; ret->order = 0; ret->minn = l_minn; ret->maxx = r_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 0) && (r_order == 1)) // Asc && Des
    {
        ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
    }
    else if((l_order == 0) && (r_order == 2)) // Asc && BOTH
    {
        if((curr_node->data > l_maxx) && (curr_node->data < r_minn))
        {
            ret->summ = total; ret->order = 0; ret->minn = l_minn; ret->maxx = r_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 1) && (r_order == 0)) // Des && Asc
    {
        ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
    }
    else if((l_order == 1) && (r_order == 1)) // Des && Des
    {
        if((curr_node->data < l_minn) && (curr_node->data > r_maxx))
        {
            ret->summ = total; ret->order = 1; ret->minn = r_minn; ret->maxx = l_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 1) && (r_order == 2)) // Des && BOTH
    {
        if((curr_node->data < l_minn) && (curr_node->data > r_maxx))
        {
            ret->summ = total; ret->order = 1; ret->minn = r_minn; ret->maxx = l_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 2) && (r_order == 0)) // BOTH && Asc
    {
        if((curr_node->data > l_maxx) && (curr_node->data < r_minn))
        {
            ret->summ = total; ret->order = 0; ret->minn = l_minn; ret->maxx = r_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 2) && (r_order == 1)) // BOTH && Des
    {
        if((curr_node->data < l_minn) && (curr_node->data > r_maxx))
        {
            ret->summ = total; ret->order = 1; ret->minn = r_minn; ret->maxx = l_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else if((l_order == 2) && (r_order == 2)) // BOTH && BOTH
    {
        if((curr_node->data > l_maxx) && (curr_node->data < r_maxx))
        {
            ret->summ = total; ret->order = 0; ret->minn = l_minn; ret->maxx = r_maxx;
        }
        else if((curr_node->data < l_minn) && (curr_node->data > r_maxx))
        {
            ret->summ = total; ret->order = 1; ret->minn = r_minn; ret->maxx = l_maxx;
        }
        else
        {
            ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
        }
    }
    else
    {
        ret->summ = total; ret->order = -1; ret->minn = -1e15; ret->maxx = 1e15;
    }
    // hi
    // printf("%lld - %lld %lld\n",curr_node->data,l_order,r_order);
    if(ret->order != -1)
    {
        // printf("%lld %lld\n",curr_node->data,total);
        ans = min(ans,total);
    }
    return ret;
}
void print()
{
  printf("%lld\n",ans);
  ans=1e15;
}
