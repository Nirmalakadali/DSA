#include "tree.h"
#include "queue.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
int main()
{
    long long int t;
    scanf("%lld",&t);
    for (long long int j = 0; j < t; j++)
    {
        long long int ans=1e15;
        long long int n;
        scanf("%lld",&n);
        long long int arr[n];
        for (long long int i = 0; i < n; i++)
        {
            scanf("%lld",&arr[i]);
        }

        Que Q=create_Q(n);
        node root = Create_Treenode(arr[0]);
        Enque(Q,root);
        for (long long int i = 1; i < n; i=i+2)
        {
            node left_node = Create_Treenode(arr[i]);
            node right_node = NULL;
            if (i+1 < n)
            {
                right_node = Create_Treenode(arr[i+1]);
            }
            Q->items[Q->front]->left = left_node;
            Q->items[Q->front]->right = right_node;
            if (left_node != NULL)
            {
                Enque(Q,left_node);
            }
            if (right_node != NULL)
            {
                Enque(Q,right_node);
            }
            Deque(Q);
        }
        // Inorder(root);
        // printf("\n");
        // Find_noise(root);
        find_ans_1(root);
        print();
    }

}