
#include "queue.h"
#include <stdlib.h>
Que create_Q(long long int size)
{
    Que Q = (Que)malloc(sizeof(struct Queue));
    Q->qsize = size;
    Q->front = 0;
    Q->rear = -1;
    Q->numElements = 0;
    Q->items = (QElement *)malloc(sizeof(QElement) *(Q->qsize));
    return Q;

}

void Enque(Que Q, node x)
{
    Q->rear = (Q->rear+1);
    Q->items[Q->rear] = x;
    Q->numElements++;
}

void Deque(Que Q)
{
    QElement x;
    x = Q->items[Q->front];
    Q->front = (Q->front + 1);
    Q->numElements--;
}

long long int Isempty(Que Q)
{
    if (Q->numElements == 0)
    {
        return 1;
    }
    return 0;
}
